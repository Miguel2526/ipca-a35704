// main.js - pequeno script para futuras interações
console.log('Site carregado — Escola de Culinária IPCA (simulação)');
